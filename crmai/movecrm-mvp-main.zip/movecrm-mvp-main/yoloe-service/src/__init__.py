# YOLOE Detection Service Package

